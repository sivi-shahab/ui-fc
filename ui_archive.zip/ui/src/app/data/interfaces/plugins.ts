export interface Plugin {
  landmarks: string;
}
