export interface MaxImageSize {
  clientMaxFileSize: number;
  clientMaxBodySize: number;
}
