export interface Statistics {
  requestCount: number;
  createdDate: string;
}
