export enum GranTypes {
  Password = 'password',
  RefreshToken = 'refresh_token',
}
