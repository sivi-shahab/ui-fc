export enum ServerStatus {
  Ready = 'OK',
}
